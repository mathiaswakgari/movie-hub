export const orders = [
  { key: "Title", value: "title" },
  { key: "Year", value: "year" },
  { key: "Rating", value: "rating" },
  { key: "Date Added", value: "date_added" },
];
